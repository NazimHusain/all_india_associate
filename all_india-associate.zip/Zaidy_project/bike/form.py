from django import forms
from .models import *


class Bike_form(forms.ModelForm):
    class Meta:
        model = Bike_details
        fields = "__all__"
