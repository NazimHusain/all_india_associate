from django.contrib import admin
from bike.models import *
from import_export.admin import ImportExportModelAdmin

# Register your models here.
# admin.site.register(Bike_details)


@admin.register(Bike_details)
class Viewadmin(ImportExportModelAdmin):
    list_display = ('loan_id','customer_phone','total_amount_to_collect','vehicle_number')
    list_per_page = 50
    search_fields = ('loan_id', 'vehicle_number')
    pass
