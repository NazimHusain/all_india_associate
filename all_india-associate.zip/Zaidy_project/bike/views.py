from pyexpat.errors import messages
from django.db.models import Q
from django.shortcuts import render, redirect
from .models import Bike_details
from .form import Bike_form
from django.contrib import messages, auth
from django.views.generic import ListView


# Create your views here.


def home_page(request):
    return render(request, 'home.html')


def load_form(request):
    form = Bike_details
    return render(request, 'show.html', {'form': form})


def add_page(request):
    form = Bike_form(request.POST)
    form.save()  # commit
    return redirect('/show')


def show_page(request):
    bike = Bike_details.objects.all()
    return render(request, 'show.html', {'bike': bike})


def search_page(request):
    given_name = request.POST["search"]
    if given_name:
        bike = Bike_details.objects.filter(Q(loan_id__iexact=given_name) | Q(vehicle_number__iexact=given_name))
        if bike:
            return render(request, 'search.html', {'search_detail': bike})
        else:
            messages.info(request, 'No Result Found ! please Enter Correct Detail..')
            return redirect('home')
    else:
        return render(request, 'home.html')


def edit_page(request, id):
    bike = Bike_details.ojects.get(id=id)
    return render(request, 'edit.html', {'bike': bike})


def update_page(request, id):
    bike = Bike_details.objects.get(id=id)
    form = Bike_form(request.POST, instance=bike)
    form.save()  # commit
    return redirect('/show')


def delete_page(request, id):
    bike = Bike_details.objects.get(id=id)
    bike.delete()
    return redirect('/show')


class post_view(ListView):
    queryset = Bike_details.objects.all()
    context_object_name = 'posts'
    paginate_by = 3
    template_name = 'show.html'
