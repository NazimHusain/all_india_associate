from django.db import models

# Create your models here.


class Bike_details(models.Model):
    loan_id = models.CharField(max_length=300, default="")
    product = models.CharField(max_length=50,default="")
    zone = models.CharField(max_length=200, null=True)
    state = models.CharField(max_length=100, null=True)
    branch = models.CharField(max_length=100, null=True)
    customer_name = models.CharField(max_length=200, null=True)
    customer_phone = models.CharField(max_length=40, null=True)
    customer_address = models.TextField(max_length=200, null=True)
    asset_model = models.CharField(max_length=100, null=True)
    engine_number = models.CharField(max_length=100, null=True)
    chassis_number = models.CharField(max_length=200, null=True)
    vehicle_number = models.CharField(max_length=100, null=True)
    loan_amount = models.FloatField()
    total_amount_to_collect = models.FloatField()
    customer_availability = models.CharField(max_length=100, null=True)
    vehicle_availability = models.CharField(max_length=100, null=True)
    status = models.CharField(max_length=100, null=True)

    def __str__(self):
        return self.loan_id

