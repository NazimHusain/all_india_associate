"""bikemanagement URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from bike.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home_page, name='home'),
    path('show', show_page, name='show'),
    path('add', add_page, name='add'),
    path('update/<int:id>', update_page, name='update'),
    path('delete/<int:id>', delete_page, name='delete'),
    path('search', search_page, name='search'),
    path('Listview',post_view, name='post_view'),
] + static(settings.STATIC_URL, document_root=settings.MEDIA_ROOT)
